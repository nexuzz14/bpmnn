<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center gap-4">
            <a href="{{ route('admin.surat-masuk.index') }}" class="p-2 rounded-lg text-gray-500 hover:bg-gray-100 transition-colors">
                <i class="ph ph-arrow-left text-xl"></i>
            </a>
            <h2 class="font-display font-semibold text-2xl text-gray-800 leading-tight">
                {{ __('Input Surat Masuk') }}
            </h2>
        </div>
    </x-slot>

    <div class="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden max-w-4xl">
        <div class="p-6 sm:px-8 sm:py-5 border-b border-gray-100">
            <h3 class="font-bold text-gray-900">Data Surat</h3>
        </div>
        <form action="{{ route('admin.surat-masuk.store') }}" method="POST" enctype="multipart/form-data" class="p-6 sm:px-8 sm:py-6 space-y-6">
            @csrf
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Nomor Surat -->
                <div class="space-y-2">
                    <label for="nomor_surat" class="block text-sm font-medium text-gray-700">Nomor Surat</label>
                    <input type="text" name="nomor_surat" id="nomor_surat" value="{{ old('nomor_surat') }}" class="w-full rounded-lg border-gray-300 focus:border-role-admin focus:ring-role-admin shadow-sm transition-colors" required placeholder="Contoh: B-123/BKB/2026">
                    @error('nomor_surat') <p class="text-red-500 text-xs">{{ $message }}</p> @enderror
                </div>

                <!-- Asal Surat -->
                <div class="space-y-2">
                    <label for="asal_surat" class="block text-sm font-medium text-gray-700">Asal Surat</label>
                    <input type="text" name="asal_surat" id="asal_surat" value="{{ old('asal_surat') }}" class="w-full rounded-lg border-gray-300 focus:border-role-admin focus:ring-role-admin shadow-sm transition-colors" required placeholder="Instansi Pengirim">
                    @error('asal_surat') <p class="text-red-500 text-xs">{{ $message }}</p> @enderror
                </div>

                <!-- Tanggal Surat -->
                <div class="space-y-2">
                    <label for="tanggal_surat" class="block text-sm font-medium text-gray-700">Tanggal Surat</label>
                    <input type="date" name="tanggal_surat" id="tanggal_surat" value="{{ old('tanggal_surat') }}" class="w-full rounded-lg border-gray-300 focus:border-role-admin focus:ring-role-admin shadow-sm transition-colors" required>
                    @error('tanggal_surat') <p class="text-red-500 text-xs">{{ $message }}</p> @enderror
                </div>

                <!-- Tanggal Terima -->
                <div class="space-y-2">
                    <label for="tanggal_terima" class="block text-sm font-medium text-gray-700">Tanggal Diterima</label>
                    <input type="date" name="tanggal_terima" id="tanggal_terima" value="{{ old('tanggal_terima') ?? date('Y-m-d') }}" class="w-full rounded-lg border-gray-300 focus:border-role-admin focus:ring-role-admin shadow-sm transition-colors text-gray-500" required>
                    @error('tanggal_terima') <p class="text-red-500 text-xs">{{ $message }}</p> @enderror
                </div>

                <!-- Perihal -->
                <div class="space-y-2 md:col-span-2">
                    <label for="perihal" class="block text-sm font-medium text-gray-700">Perihal</label>
                    <textarea name="perihal" id="perihal" rows="4" class="w-full rounded-lg border-gray-300 focus:border-role-admin focus:ring-role-admin shadow-sm transition-colors" required placeholder="Tuliskan perihal surat...">{{ old('perihal') }}</textarea>
                    @error('perihal') <p class="text-red-500 text-xs">{{ $message }}</p> @enderror
                </div>

                <!-- Jenis Surat -->
                <div class="space-y-2">
                    <label for="jenis_surat" class="block text-sm font-medium text-gray-700">Klasifikasi Surat</label>
                    <select name="jenis_surat" id="jenis_surat" class="w-full rounded-lg border-gray-300 focus:border-role-admin focus:ring-role-admin shadow-sm transition-colors text-gray-500" required>
                        <option value="" disabled {{ old('jenis_surat') ? '' : 'selected' }}>Pilih klasifikasi...</option>
                        <option value="fisik" {{ old('jenis_surat') == 'fisik' ? 'selected' : '' }}>Fisik</option>
                        <option value="digital" {{ old('jenis_surat') == 'digital' ? 'selected' : '' }}>Digital</option>
                    </select>
                    @error('jenis_surat') <p class="text-red-500 text-xs">{{ $message }}</p> @enderror
                </div>

                <!-- File Surat -->
                <div class="space-y-2 md:col-span-2 mt-4">
                    <div class="border-2 border-dashed border-gray-300 rounded-xl p-10 flex flex-col items-center justify-center text-center hover:bg-gray-50 transition-colors relative cursor-pointer" onclick="document.getElementById('file_surat').click()">
                        <p id="file-name-display" class="text-gray-500 text-sm mb-3">Seret & lepas file PDF atau Word di sini</p>
                        <button type="button" id="file-btn" class="px-4 py-2 bg-white border border-[#055a40] text-[#055a40] font-medium text-sm rounded-lg shadow-sm hover:bg-green-50 pointer-events-none">
                            Pilih File
                        </button>
                        <p class="text-xs text-gray-400 mt-3">PDF / Word maks. 10 MB <br><span class="text-orange-500 font-medium">(Opsional: Boleh dikosongkan jika belum ada scan)</span></p>
                        <input type="file" name="file_surat" id="file_surat" accept=".pdf,.doc,.docx" class="absolute inset-0 w-full h-full opacity-0 cursor-pointer" onchange="if(this.files.length) { document.getElementById('file-name-display').innerHTML = '<span class=\'font-bold text-[#055a40] text-base\'>📄 File Terpilih:</span><br><span class=\'text-gray-800 mt-1 block\'>' + this.files[0].name + '</span>'; document.getElementById('file-btn').innerText = 'Ganti File'; document.getElementById('file-btn').className = 'px-4 py-2 bg-[#055a40] text-white font-medium text-sm rounded-lg shadow-sm pointer-events-none mt-2'; }">
                    </div>
                    @error('file_surat') <p class="text-red-500 text-xs">{{ $message }}</p> @enderror
                </div>
            </div>

            <div class="pt-4 flex items-center justify-end gap-3 border-t border-gray-100">
                <a href="{{ route('admin.surat-masuk.index') }}" class="px-5 py-2 text-sm font-medium text-gray-600 bg-gray-50 hover:bg-gray-100 rounded-lg transition-colors border border-gray-200">Batal</a>
                <button type="submit" id="submit-btn" class="px-5 py-2 text-sm font-medium text-white bg-role-admin hover:bg-role-admin/90 rounded-lg transition-colors shadow-sm flex items-center" onclick="if(this.closest('form').checkValidity()) { this.innerHTML = '<i class=\'ph ph-spinner animate-spin mr-2\'></i> Menyimpan...'; this.classList.add('opacity-75', 'cursor-wait'); }">
                    Simpan Surat Masuk
                </button>
            </div>
        </form>
    </div>
</x-app-layout>
